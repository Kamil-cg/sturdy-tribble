sap.ui.define(["sap/fe/core/AppComponent"],function(t){"use strict";return t.extend("btp.starterkit.customer.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map